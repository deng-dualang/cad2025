import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

from Mfunc import Mfunc
from Hfunc import Hfunc
from A1func import A1func
from A1dotfunc import A1dotfunc
from AEfunc import AEfunc
from AM_dynamics import AM_dynamics
from GM_dynamics import GM_dynamics

# 全域參數定義
l1, l2, l3, l4 = 1, 2, 1.5, 0.9      # 各桿長
g = -9.8                             # 重力加速度
Rho1 = 2.7143E3                      # 密度
Rho2 = Rho1
Rho3 = Rho1
E1 = 71.7e9                          # 楊氏係數
E2 = E1
E3 = E1
A_1 = 0.75 * 3 * 10 ** -4            # 橫截面面積
A_2 = A_1
A_3 = A_1
I1 = 0.1055 * 10 ** -8               # 慣性矩
I2 = I1
I3 = I1

# 各桿質量
m1 = A_1 * Rho1 * l1
m2 = A_2 * Rho2 * l2
m3 = A_3 * Rho3 * l3

dt = 0.01
timeSpan = np.arange(0, 1.4 + dt, dt)    # 模擬時間

q_0 = np.array([np.pi/4, -0.6286, -0.3179])   # 初始角度
dq_0 = np.zeros(3)                            # 初始角速度
z0 = np.concatenate([q_0, dq_0])              # 初始狀態

def run_sim():
    """
    進行四連桿動力學數值模擬
    """
    # 使用 solve_ivp 解 AM_dynamics
    sol = solve_ivp(
        lambda t, z: AM_dynamics(l1, l2, l3, m1, m2, m3, g, t, z, Mfunc, Hfunc, A1func, A1dotfunc),
        [timeSpan[0], timeSpan[-1]], z0, t_eval=timeSpan, max_step=1e-4
    )
    zGM = sol.y.T      # 解的狀態矩陣

    # 封裝結果
    class GM:
        pass
    GM.q1 = zGM[:, 0]
    GM.q2 = zGM[:, 1]
    GM.q3 = zGM[:, 2]
    GM.dq1 = zGM[:, 3]
    GM.dq2 = zGM[:, 4]
    GM.dq3 = zGM[:, 5]

    # 計算 constraint 誤差
    AE_GM = AEfunc(l1, l2, l3, l4, GM.q1, GM.q2, GM.q3)

    # Constraint error 曲線
    plt.figure()
    plt.plot(timeSpan, AE_GM, color='#77AC30', linewidth=2)
    plt.legend(['Agumented Method'])
    plt.xlabel('time(s)')
    plt.grid(True, which='both')
    plt.title('Constraint Error')

    # q1 曲線
    plt.figure()
    plt.plot(timeSpan, GM.q1 * 180 / np.pi, 'k-', linewidth=1)
    plt.legend(['GM'])
    plt.xlabel('time(s)')
    plt.title('$\\theta_1$')

    # q2 曲線
    plt.figure()
    plt.plot(timeSpan, GM.q2 * 180 / np.pi, 'k-', linewidth=1)
    plt.legend(['GM'])
    plt.xlabel('time(s)')
    plt.title('$\\theta_2$')
    plt.ylabel('Angle (deg)')

    # 末端點 y 坐標
    yp = l1 * np.sin(GM.q1) + l2 * np.sin(GM.q2)
    plt.figure()
    plt.plot(timeSpan, yp, 'k-', linewidth=1.5)
    plt.ylabel('y [m]')
    plt.xlabel('Time [s]')

    # 末端點 x 坐標
    xp = l1 * np.cos(GM.q1) + l2 * np.cos(GM.q2)
    plt.figure()
    plt.plot(timeSpan, xp, 'b-', linewidth=1.5)
    plt.ylabel('X [m]')
    plt.xlabel('Time [s]')

    plt.show()

if __name__ == "__main__":
    run_sim()