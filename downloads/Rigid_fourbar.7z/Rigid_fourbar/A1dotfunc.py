import numpy as np

def A1dotfunc(dq1, dq2, dq3, l1, l2, l3, q1, q2, q3):
    """
    計算 constraint Jacobian 的導數 (A1dot)，常用於多體系統動力學的限制條件微分項。
    dq1, dq2, dq3: 各連桿的角速度
    l1, l2, l3: 各連桿長度
    q1, q2, q3: 各連桿角度
    傳回 shape 為 (3, 2) 的 numpy 陣列
    """
    # 各項根據 symbolic 導數展開，對應 constraint 的速度項
    arr = [
        -dq1 * l1 * np.cos(q1),    # 第一行第一列：-dq1*l1*cos(q1)
        -dq2 * l2 * np.cos(q2),    # 第一行第二列：-dq2*l2*cos(q2)
        dq3 * l3 * np.cos(q3),     # 第一行第三列： dq3*l3*cos(q3)
        -dq1 * l1 * np.sin(q1),    # 第二行第一列：-dq1*l1*sin(q1)
        -dq2 * l2 * np.sin(q2),    # 第二行第二列：-dq2*l2*sin(q2)
        dq3 * l3 * np.sin(q3)      # 第二行第三列： dq3*l3*sin(q3)
    ]
    # 將一維陣列 reshape 成 3x2 矩陣
    return np.array(arr).reshape(3, 2)