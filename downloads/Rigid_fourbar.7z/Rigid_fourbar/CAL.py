import sympy as sp

# 定義符號
t, x = sp.symbols('t x')
q1, q2, q3 = sp.symbols('q1 q2 q3')
dq1, dq2, dq3 = sp.symbols('dq1 dq2 dq3')
l1, l2, l3, l4, m1, m2, m3, g = sp.symbols('l1 l2 l3 l4 m1 m2 m3 g')
tor1 = 0

# Link 1 轉動矩陣
Q1 = sp.Matrix([[sp.cos(q1), -sp.sin(q1)], [sp.sin(q1), sp.cos(q1)]])
r1 = lambda x: Q1 @ sp.Matrix([x, 0])           # Link 1 上任意點位置
v1 = lambda x: sp.diff(r1(x), q1) * dq1         # Link 1 任意點速度
T1 = 0.5 * m1 / l1 * sp.integrate((v1(x).T @ v1(x))[0], (x, 0, l1))  # Link 1 動能
V1 = m1 * g / l1 * sp.integrate((r1(x).T @ sp.Matrix([0, 1]))[0], (x, 0, l1))  # Link 1 位能

# Link 2
Q2 = sp.Matrix([[sp.cos(q2), -sp.sin(q2)], [sp.sin(q2), sp.cos(q2)]])
r2 = lambda x: r1(l1) + Q2 @ sp.Matrix([x, 0])  # Link 2 任意點位置
v2 = lambda x: sp.diff(r2(x), q1) * dq1 + sp.diff(r2(x), q2) * dq2    # Link 2 任意點速度
T2 = 0.5 * m2 / l2 * sp.integrate((v2(x).T @ v2(x))[0], (x, 0, l2))  # 動能
V2 = m2 * g / l2 * sp.integrate((r2(x).T @ sp.Matrix([0, 1]))[0], (x, 0, l2))  # 位能

# Link 3
Q3 = sp.Matrix([[sp.cos(q3), -sp.sin(q3)], [sp.sin(q3), sp.cos(q3)]])
r3 = lambda x: sp.Matrix([l4, 0]) + Q3 @ sp.Matrix([x, 0])           # Link 3 任意點位置
v3 = lambda x: sp.diff(r3(x), q1) * dq1 + sp.diff(r3(x), q2) * dq2 + sp.diff(r3(x), q3) * dq3    # Link 3 任意點速度
T3 = 0.5 * m3 / l3 * sp.integrate((v3(x).T @ v3(x))[0], (x, 0, l3))
V3 = m3 * g / l3 * sp.integrate((r3(x).T @ sp.Matrix([0, 1]))[0], (x, 0, l3))

# 能量總和
T = T1 + T2 + T3      # 動能總和
V = V1 + V2 + V3      # 位能總和
E = T + V             # 總能量

q = sp.Matrix([q1, q2, q3])
dq = sp.Matrix([dq1, dq2, dq3])

# 質量矩陣與 H 項
Mass_matrix = sp.simplify(sp.hessian(T, dq))
H_matrix = sp.simplify((sp.hessian(T, dq) * dq).jacobian(q) * dq - sp.diff(T, q).T + sp.diff(V, q).T)
M1 = sp.Matrix([tor1, 0])

# constraint 與 Jacobian
A2 = r2(l2) - r3(l3)
A = sp.simplify(A2.jacobian(q) * dq)
A1 = sp.simplify(A.jacobian(dq).T)
AE = sp.simplify(A2.T * A2)

# Jacobian 對 q 的導數（A1dot）
A1dot = A1.copy()
for n in range(A1.rows):
    A1dot[n, :] = (A1.row(n).jacobian(q) * dq).T

A1dot = sp.simplify(A1dot)

# 可用 sympy.lambdify 或 codegen 輸出對應數值函式