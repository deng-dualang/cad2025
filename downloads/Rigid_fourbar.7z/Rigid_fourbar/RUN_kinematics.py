import numpy as np
import matplotlib.pyplot as plt

# 四連桿長度與質量設定
l1, l2, l3, l4 = 0.2, 0.6, 0.9, 1.0
g = -9.8
Rho = 2714.3
A = 0.75 * 3e-4

m1 = A * Rho * l1
m2 = A * Rho * l2
m3 = A * Rho * l3

I1 = (1/12) * m1 * l1 ** 2
I2 = (1/12) * m2 * l2 ** 2
I3 = (1/12) * m3 * l3 ** 2

dt = 0.01
T = 12  # 360度/30度每秒 = 12秒
timeSpan = np.arange(0, T + dt, dt)

# 指定主動桿角度與角速度
q1_traj = np.deg2rad(30) * timeSpan
dq1_traj = np.full_like(q1_traj, np.deg2rad(30))  # 30度/sec 恆定角速度
ddq1_traj = np.zeros_like(q1_traj)

def initial_guess(q1):
    return np.deg2rad(60), np.deg2rad(-60)

def fourbar_loop_closure(q1, l1, l2, l3, l4, q2_init, q3_init, tol=1e-12, max_iter=50):
    q2, q3 = q2_init, q3_init
    for _ in range(max_iter):
        F1 = l1 * np.cos(q1) + l2 * np.cos(q2) + l3 * np.cos(q3) - l4
        F2 = l1 * np.sin(q1) + l2 * np.sin(q2) + l3 * np.sin(q3)
        F = np.array([F1, F2])
        J = np.zeros((2,2))
        eps = 1e-8
        for i in range(2):
            dq = np.zeros(2)
            dq[i] = eps
            q2_pert, q3_pert = q2 + dq[0], q3 + dq[1]
            F1p = l1 * np.cos(q1) + l2 * np.cos(q2_pert) + l3 * np.cos(q3_pert) - l4
            F2p = l1 * np.sin(q1) + l2 * np.sin(q2_pert) + l3 * np.sin(q3_pert)
            Fp = np.array([F1p, F2p])
            J[:, i] = (Fp - F) / eps
        dx = np.linalg.solve(J, -F)
        q2 += dx[0]
        q3 += dx[1]
        if np.linalg.norm(dx) < tol:
            break
    return q2, q3

def fourbar_velocity(q1, dq1, q2, q3, l1, l2, l3, l4):
    # 求解 q2, q3 的一階導數 (速度)
    # 由 constraint 方程對時間微分，解 dq2, dq3
    # F1 = l1 cos(q1) + l2 cos(q2) + l3 cos(q3) - l4 = 0
    # F2 = l1 sin(q1) + l2 sin(q2) + l3 sin(q3) = 0
    # dF/dt = (∂F/∂q1)*dq1 + (∂F/∂q2)*dq2 + (∂F/∂q3)*dq3 = 0
    A = np.array([
        [-l2 * np.sin(q2), -l3 * np.sin(q3)],
        [l2 * np.cos(q2),  l3 * np.cos(q3)]
    ])
    b = np.array([
        l1 * np.sin(q1) * dq1,
        -l1 * np.cos(q1) * dq1
    ])
    dq2_dq3 = np.linalg.solve(A, b)
    dq2, dq3 = dq2_dq3[0], dq2_dq3[1]
    return dq2, dq3

def fourbar_acceleration(q1, dq1, ddq1, q2, dq2, q3, dq3, l1, l2, l3, l4):
    # 求解 q2, q3 的二階導數 (加速度)
    # d^2F/dt^2 = J*[ddq2, ddq3] + C = -∂^2F/∂t^2
    # 先建立 constraint 的一階雅可比（同 velocity），再左右兩邊整理
    # F1'' = -l1*cos(q1)*dq1^2 - l2*cos(q2)*dq2^2 - l3*cos(q3)*dq3^2
    # F2'' = -l1*sin(q1)*dq1^2 - l2*sin(q2)*dq2^2 - l3*sin(q3)*dq3^2
    J = np.array([
        [-l2 * np.sin(q2), -l3 * np.sin(q3)],
        [l2 * np.cos(q2),  l3 * np.cos(q3)]
    ])
    b = np.array([
        -l1 * np.cos(q1) * dq1**2 - l2 * np.cos(q2) * dq2**2 - l3 * np.cos(q3) * dq3**2,
        -l1 * np.sin(q1) * dq1**2 - l2 * np.sin(q2) * dq2**2 - l3 * np.sin(q3) * dq3**2
    ])
    ddq2_ddq3 = np.linalg.solve(J, b)
    ddq2, ddq3 = ddq2_ddq3[0], ddq2_ddq3[1]
    return ddq2, ddq3

# 計算 q2, q3, dq2, dq3, ddq2, ddq3
q2_traj = np.zeros_like(q1_traj)
q3_traj = np.zeros_like(q1_traj)
dq2_traj = np.zeros_like(q1_traj)
dq3_traj = np.zeros_like(q1_traj)
ddq2_traj = np.zeros_like(q1_traj)
ddq3_traj = np.zeros_like(q1_traj)

q2, q3 = initial_guess(q1_traj[0])
dq2, dq3 = 0, 0
for i, (q1, dq1) in enumerate(zip(q1_traj, dq1_traj)):
    q2, q3 = fourbar_loop_closure(q1, l1, l2, l3, l4, q2, q3)
    dq2, dq3 = fourbar_velocity(q1, dq1, q2, q3, l1, l2, l3, l4)
    ddq2, ddq3 = fourbar_acceleration(q1, dq1, 0, q2, dq2, q3, dq3, l1, l2, l3, l4)
    q2_traj[i] = q2
    q3_traj[i] = q3
    dq2_traj[i] = dq2
    dq3_traj[i] = dq3
    ddq2_traj[i] = ddq2
    ddq3_traj[i] = ddq3

# 計算各桿質心位置
xG1 = l1/2 * np.cos(q1_traj)
yG1 = l1/2 * np.sin(q1_traj)
xG2 = l1 * np.cos(q1_traj) + l2/2 * np.cos(q2_traj)
yG2 = l1 * np.sin(q1_traj) + l2/2 * np.sin(q2_traj)
xG3 = l1 * np.cos(q1_traj) + l2 * np.cos(q2_traj) + l3/2 * np.cos(q3_traj)
yG3 = l1 * np.sin(q1_traj) + l2 * np.sin(q2_traj) + l3/2 * np.sin(q3_traj)

# 計算各桿質心速度
vG1x = -l1/2 * np.sin(q1_traj) * dq1_traj
vG1y =  l1/2 * np.cos(q1_traj) * dq1_traj
vG2x = -l1 * np.sin(q1_traj) * dq1_traj - l2/2 * np.sin(q2_traj) * dq2_traj
vG2y =  l1 * np.cos(q1_traj) * dq1_traj + l2/2 * np.cos(q2_traj) * dq2_traj
vG3x = (-l1 * np.sin(q1_traj) * dq1_traj
        -l2 * np.sin(q2_traj) * dq2_traj
        -l3/2 * np.sin(q3_traj) * dq3_traj)
vG3y = (l1 * np.cos(q1_traj) * dq1_traj
        +l2 * np.cos(q2_traj) * dq2_traj
        +l3/2 * np.cos(q3_traj) * dq3_traj)

# 計算各桿質心加速度
aG1x = -l1/2 * (np.cos(q1_traj) * dq1_traj**2)
aG1y = -l1/2 * (np.sin(q1_traj) * dq1_traj**2)
aG2x = (-l1 * np.cos(q1_traj) * dq1_traj**2
        -l2/2 * np.cos(q2_traj) * dq2_traj**2)
aG2y = (-l1 * np.sin(q1_traj) * dq1_traj**2
        -l2/2 * np.sin(q2_traj) * dq2_traj**2)
aG3x = (-l1 * np.cos(q1_traj) * dq1_traj**2
        -l2 * np.cos(q2_traj) * dq2_traj**2
        -l3/2 * np.cos(q3_traj) * dq3_traj**2)
aG3y = (-l1 * np.sin(q1_traj) * dq1_traj**2
        -l2 * np.sin(q2_traj) * dq2_traj**2
        -l3/2 * np.sin(q3_traj) * dq3_traj**2)

# 求主動桿所需 Torque（能量法/動力學法）
# ΣM1 = I1*ddq1 + m1*rG1^2*ddq1 + m1*(rG1 × aG1) + ...
Torque = np.zeros_like(q1_traj)
for i in range(len(q1_traj)):
    # 各桿慣性力矩
    # 主動桿
    M1 = I1 * 0 + m1 * ((l1/2)**2) * 0   # ddq1=0
    # 第二桿
    M2 = 0  # 沒有驅動
    # 第三桿
    M3 = 0
    # 重力力矩
    G1 = -m1 * g * (l1/2) * np.cos(q1_traj[i])
    G2 = -m2 * g * (l1 * np.cos(q1_traj[i]) + l2/2 * np.cos(q2_traj[i]))
    G3 = -m3 * g * (l1 * np.cos(q1_traj[i]) + l2 * np.cos(q2_traj[i]) + l3/2 * np.cos(q3_traj[i]))
    # 零加速度下，只需平衡重力力矩
    Torque[i] = G1 + G2 + G3

plt.figure()
plt.plot(timeSpan, Torque, 'r-', label='Required Torque [Nm]')
plt.xlabel('Time [s]')
plt.ylabel('Torque (Nm)')
plt.title('Torque required for 30 deg/s steady rotation')
plt.grid()
plt.legend()

plt.figure()
plt.plot(timeSpan, np.rad2deg(q1_traj), label='q1 (deg)')
plt.plot(timeSpan, np.rad2deg(q2_traj), label='q2 (deg)')
plt.plot(timeSpan, np.rad2deg(q3_traj), label='q3 (deg)')
plt.xlabel('Time [s]')
plt.ylabel('Angle [deg]')
plt.title('Four-bar Dynamics (30 deg/s)')
plt.legend()
plt.grid()

plt.show()