import numpy as np

def Mfunc(l1, l2, l3, m1, m2, m3, q1, q2):
    """
    計算質量矩陣 (Inertia matrix, M)，用於動力學方程 M*ddq = F。
    返回 shape 為 (3, 3) 的 numpy 矩陣
    """
    t3 = q1 - q2                 # 差角
    t4 = np.cos(t3)              # 差角的餘弦
    t5 = (l1 * l2 * m2 * t4) / 2.0   # 交互項
    # 各項依據慣性關係展開，對應於每個自由度的質量矩陣
    arr = [
        (l1 ** 2 * (m1 + m2 * 3.0)) / 3.0, t5, 0.0,
        t5, (l2 ** 2 * m2) / 3.0, 0.0,
        0.0, 0.0, (l3 ** 2 * m3) / 3.0
    ]
    return np.array(arr).reshape(3, 3)