import numpy as np

def AEfunc(l1, l2, l3, l4, q1, q2, q3):
    """
    計算 constraint error（即 AE），用來表示末端點與預期位置的距離平方和，適合用於分析誤差。
    l1, l2, l3, l4: 各桿長
    q1, q2, q3: 各桿角度
    返回 constraint error 的數值（純量或向量）
    """
    # AE = (x 誤差)^2 + (y 誤差)^2
    return (l4 - l1 * np.cos(q1) - l2 * np.cos(q2) + l3 * np.cos(q3)) ** 2 + \
           (l1 * np.sin(q1) + l2 * np.sin(q2) - l3 * np.sin(q3)) ** 2