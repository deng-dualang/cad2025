import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

from Mfunc import Mfunc
from Hfunc import Hfunc
from A1func import A1func
from A1dotfunc import A1dotfunc
from AEfunc import AEfunc
from AM_dynamics import AM_dynamics
from GM_dynamics import GM_dynamics

# 全域參數定義
l1, l2, l3, l4 = 1, 2, 1.5, 0.9
g = -9.8
Rho1 = 2.7143E3
Rho2 = Rho1
Rho3 = Rho1
E1 = 71.7e9
E2 = E1
E3 = E1
A_1 = 0.75 * 3 * 10 ** -4
A_2 = A_1
A_3 = A_1
I1 = 0.1055 * 10 ** -8
I2 = I1
I3 = I1

m1 = A_1 * Rho1 * l1
m2 = A_2 * Rho2 * l2
m3 = A_3 * Rho3 * l3

dt = 0.01
timeSpan = np.arange(0, 1.4 + dt, dt)

q_0 = np.array([np.pi/4, -0.6286, -0.3179])
dq_0 = np.zeros(3)
z0 = np.concatenate([q_0, dq_0])

def solve_fourbar_kinematics(q1_traj, l1, l2, l3, l4, q2_init, q3_init):
    """
    已知 q1(t) 序列，利用 AEfunc 求解 q2(t)、q3(t)
    """
    q2_traj = np.zeros_like(q1_traj)
    q3_traj = np.zeros_like(q1_traj)
    q2 = q2_init
    q3 = q3_init
    for i, q1 in enumerate(q1_traj):
        # 使用牛頓法聯立解 constraint
        def f(x):
            return AEfunc(l1, l2, l3, l4, q1, x[0], x[1])
        x = np.array([q2, q3])
        for _ in range(10):  # 迭代 10 次
            F = np.array(f(x))
            J = np.zeros((2, 2))
            eps = 1e-8
            for j in range(2):
                x1 = x.copy()
                x1[j] += eps
                F1 = np.array(f(x1))
                J[:, j] = (F1 - F) / eps
            dx = np.linalg.solve(J, -F)
            x += dx
            if np.linalg.norm(dx) < 1e-10:
                break
        q2, q3 = x
        q2_traj[i] = q2
        q3_traj[i] = q3
    return q2_traj, q3_traj

def run_sim():
    """
    進行四連桿運動學與動力學模擬
    """
    # === (A) Kinematics 模擬 ===
    # 假設 q1(t) 為線性(固定速率)輸入
    q1_kin = np.linspace(q_0[0], q_0[0] + np.deg2rad(30), len(timeSpan))  # 例：主動桿轉動30度
    q2_kin, q3_kin = solve_fourbar_kinematics(q1_kin, l1, l2, l3, l4, q_0[1], q_0[2])

    # 繪製運動學結果
    plt.figure()
    plt.plot(timeSpan, q1_kin * 180 / np.pi, label='q1 (kin)')
    plt.plot(timeSpan, q2_kin * 180 / np.pi, label='q2 (kin)')
    plt.plot(timeSpan, q3_kin * 180 / np.pi, label='q3 (kin)')
    plt.xlabel('Time [s]')
    plt.ylabel('Angle (deg)')
    plt.title('Kinematics (四連桿運動學)')
    plt.legend()
    plt.grid()

    # 末端點軌跡
    xp_kin = l1 * np.cos(q1_kin) + l2 * np.cos(q2_kin)
    yp_kin = l1 * np.sin(q1_kin) + l2 * np.sin(q2_kin)

    plt.figure()
    plt.plot(xp_kin, yp_kin, label='End point traj (Kinematics)')
    plt.xlabel('X [m]')
    plt.ylabel('Y [m]')
    plt.title('Kinematics End-point path')
    plt.grid()
    plt.legend()

    # === (B) Dynamics 動力學數值模擬 ===
    sol = solve_ivp(
        lambda t, z: AM_dynamics(l1, l2, l3, m1, m2, m3, g, t, z, Mfunc, Hfunc, A1func, A1dotfunc),
        [timeSpan[0], timeSpan[-1]], z0, t_eval=timeSpan, max_step=1e-4
    )
    zGM = sol.y.T

    class GM:
        pass
    GM.q1 = zGM[:, 0]
    GM.q2 = zGM[:, 1]
    GM.q3 = zGM[:, 2]
    GM.dq1 = zGM[:, 3]
    GM.dq2 = zGM[:, 4]
    GM.dq3 = zGM[:, 5]

    AE_GM = AEfunc(l1, l2, l3, l4, GM.q1, GM.q2, GM.q3)

    plt.figure()
    plt.plot(timeSpan, AE_GM, color='#77AC30', linewidth=2)
    plt.legend(['Augmented Method'])
    plt.xlabel('time(s)')
    plt.grid(True, which='both')
    plt.title('Constraint Error (Dynamics)')

    plt.figure()
    plt.plot(timeSpan, GM.q1 * 180 / np.pi, 'k-', linewidth=1, label='q1 (dyn)')
    plt.plot(timeSpan, GM.q2 * 180 / np.pi, 'b-', linewidth=1, label='q2 (dyn)')
    plt.plot(timeSpan, GM.q3 * 180 / np.pi, 'g-', linewidth=1, label='q3 (dyn)')
    plt.xlabel('time(s)')
    plt.ylabel('Angle (deg)')
    plt.legend()
    plt.title('Dynamics (四連桿動力學)')

    yp = l1 * np.sin(GM.q1) + l2 * np.sin(GM.q2)
    plt.figure()
    plt.plot(timeSpan, yp, 'k-', linewidth=1.5)
    plt.ylabel('y [m]')
    plt.xlabel('Time [s]')
    plt.title('End-point y (Dynamics)')

    xp = l1 * np.cos(GM.q1) + l2 * np.cos(GM.q2)
    plt.figure()
    plt.plot(timeSpan, xp, 'b-', linewidth=1.5)
    plt.ylabel('X [m]')
    plt.xlabel('Time [s]')
    plt.title('End-point x (Dynamics)')

    plt.show()

if __name__ == "__main__":
    run_sim()