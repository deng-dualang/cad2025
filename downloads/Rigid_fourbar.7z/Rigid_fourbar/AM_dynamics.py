import numpy as np

def AM_dynamics(l1, l2, l3, m1, m2, m3, g, t, Z, Mfunc, Hfunc, A1func, A1dotfunc):
    """
    四連桿系統的增廣法 (Augmented Method) 動力學方程。
    t: 當前時間點
    Z: 當前狀態向量 [q1, q2, q3, dq1, dq2, dq3]
    Mfunc, Hfunc, A1func, A1dotfunc: 分別為質量矩陣、廣義力、constraint Jacobian 及其導數的函數
    回傳 dZ: 狀態導數 [dq1, dq2, dq3, ddq1, ddq2, ddq3]
    """
    # 擷取廣義座標與其導數
    q = Z[:3]    # q = [q1, q2, q3]
    dq = Z[3:6]  # dq = [dq1, dq2, dq3]

    q1, q2, q3 = q
    dq1, dq2, dq3 = dq

    # 計算質量矩陣、廣義力、constraint Jacobian 及其導數
    M = Mfunc(l1, l2, l3, m1, m2, m3, q1, q2)
    H = Hfunc(dq1, dq2, g, l1, l2, l3, m1, m2, m3, q1, q2, q3)
    A1 = A1func(l1, l2, l3, q1, q2, q3).T
    A1dot = A1dotfunc(dq1, dq2, dq3, l1, l2, l3, q1, q2, q3).T

    # 設定外力（扭矩）時程，0.7秒前後不同
    if t <= 0.7:
        TO = 1 * (1 - np.exp(-t / 0.167))    # 開始時快速上升至1
    else:
        TO = 0.1 * (1 - np.exp(-t / 0.167))  # 0.7秒後降為0.1

    FTT = np.array([TO, 0, 0])   # 外力（只對第一個自由度作用）
    F = FTT - H                  # 扣除廣義力後的淨推力

    # 增廣矩陣與右側向量（包含 constraint）
    M_AM = np.block([
        [M, -A1.T],          # 上半部：動力學與 constraint
        [-A1, np.zeros((2, 2))]  # 下半部：constraint 本身
    ])
    F_AM = np.concatenate([F, np.dot(A1dot, dq)])  # 結合 constraint 微分項

    # 解聯立方程，取得加速度與 constraint 反力
    X = np.linalg.pinv(M_AM) @ F_AM

    # 合成狀態導數（速度與加速度）
    dZ = np.concatenate([dq, X[:3]])
    return dZ