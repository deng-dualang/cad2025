import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

# 四連桿長度設定
l1 = 0.2   # 主動短桿
l2 = 0.6   # 第二運動桿
l3 = 0.9   # 最長運動桿
l4 = 1.0   # 地面桿

dt = 0.01
T = 12  # 360度/30度每秒 = 12秒
timeSpan = np.arange(0, T + dt, dt)

# 主動桿角度(q1)給定（360度繞行）
q1_0 = np.deg2rad(0)
q1_traj = q1_0 + np.deg2rad(30) * timeSpan  # 30 deg/sec 速度

def initial_guess(q1):
    # 粗略初猜
    return np.deg2rad(60), np.deg2rad(-60)

def fourbar_loop_closure(q1, l1, l2, l3, l4, q2_init, q3_init, tol=1e-12, max_iter=50):
    q2, q3 = q2_init, q3_init
    for _ in range(max_iter):
        F1 = l1 * np.cos(q1) + l2 * np.cos(q2) + l3 * np.cos(q3) - l4
        F2 = l1 * np.sin(q1) + l2 * np.sin(q2) + l3 * np.sin(q3)
        F = np.array([F1, F2])
        J = np.zeros((2,2))
        eps = 1e-8
        for i in range(2):
            dq = np.zeros(2)
            dq[i] = eps
            q2_pert, q3_pert = q2 + dq[0], q3 + dq[1]
            F1p = l1 * np.cos(q1) + l2 * np.cos(q2_pert) + l3 * np.cos(q3_pert) - l4
            F2p = l1 * np.sin(q1) + l2 * np.sin(q2_pert) + l3 * np.sin(q3_pert)
            Fp = np.array([F1p, F2p])
            J[:, i] = (Fp - F) / eps
        dx = np.linalg.solve(J, -F)
        q2 += dx[0]
        q3 += dx[1]
        if np.linalg.norm(dx) < tol:
            break
    return q2, q3

# 計算 q2, q3 序列
q2_traj = np.zeros_like(q1_traj)
q3_traj = np.zeros_like(q1_traj)
q2, q3 = initial_guess(q1_traj[0])
for i, q1 in enumerate(q1_traj):
    q2, q3 = fourbar_loop_closure(q1, l1, l2, l3, l4, q2, q3)
    q2_traj[i] = q2
    q3_traj[i] = q3

# 計算末端點軌跡
x_end = l1 * np.cos(q1_traj) + l2 * np.cos(q2_traj)
y_end = l1 * np.sin(q1_traj) + l2 * np.sin(q2_traj)

# 繪圖
plt.figure()
plt.plot(timeSpan, np.rad2deg(q1_traj), label='q1 (deg)')
plt.plot(timeSpan, np.rad2deg(q2_traj), label='q2 (deg)')
plt.plot(timeSpan, np.rad2deg(q3_traj), label='q3 (deg)')
plt.xlabel('Time [s]')
plt.ylabel('Angle [deg]')
plt.title('Four-bar Kinematics (Full 360 deg)')
plt.legend()
plt.grid()

plt.figure()
plt.plot(x_end, y_end, label='End-point path')
plt.xlabel('X [m]')
plt.ylabel('Y [m]')
plt.title('Four-bar End-point Trajectory')
plt.legend()
plt.axis('equal')
plt.grid()
plt.show()

# === 動畫模擬 ===
fig, ax = plt.subplots(figsize=(6,6))
ax.set_aspect('equal')
ax.set_xlim(-1.2, 1.2)
ax.set_ylim(-1.2, 1.2)
ax.grid(True)
ground_A = np.array([0, 0])
ground_B = np.array([l4, 0])
line, = ax.plot([], [], 'o-', lw=3, color='tab:blue')
trace, = ax.plot([], [], '-', lw=1, color='tab:red', alpha=0.5)
trace_x, trace_y = [], []

def get_coords(i):
    Ax, Ay = ground_A
    Bx, By = ground_B
    Px = l1 * np.cos(q1_traj[i])
    Py = l1 * np.sin(q1_traj[i])
    Qx = Px + l2 * np.cos(q2_traj[i])
    Qy = Py + l2 * np.sin(q2_traj[i])
    return np.array([
        [Ax, Ay],
        [Px, Py],
        [Qx, Qy],
        [Bx, By]
    ])

def init():
    line.set_data([], [])
    trace.set_data([], [])
    return line, trace

def update(i):
    coords = get_coords(i)
    line.set_data(coords[:,0], coords[:,1])
    trace_x.append(coords[2,0])
    trace_y.append(coords[2,1])
    trace.set_data(trace_x, trace_y)
    return line, trace

ani = FuncAnimation(fig, update, frames=len(timeSpan),
                    init_func=init, blit=True, interval=20, repeat=True)

plt.title('Four-bar Linkage Animation (Kinematics)')
plt.show()