Python programs adopted from:

https://github.com/nopour/Four-bar-linkage