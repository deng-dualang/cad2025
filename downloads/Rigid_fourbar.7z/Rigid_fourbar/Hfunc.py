import numpy as np

def Hfunc(dq1, dq2, g, l1, l2, l3, m1, m2, m3, q1, q2, q3):
    """
    計算 generalized force（科氏力＋重力＋離心力等非保守項），對應動力學方程右側 H 項。
    返回 shape 為 (3,) 的 numpy 陣列
    """
    t2 = np.cos(q1)              # q1 的餘弦
    t4 = q1 - q2                 # 差角
    t5 = np.sin(t4)              # 角差的正弦
    # 各廣義座標的 generalized force
    H1 = (l1 * (g * m1 * t2 + g * m2 * t2 * 2.0 + dq2 ** 2 * l2 * m2 * t5)) / 2.0
    H2 = (l2 * m2 * (g * np.cos(q2) - dq1 ** 2 * l1 * t5)) / 2.0
    H3 = (g * l3 * m3 * np.cos(q3)) / 2.0
    return np.array([H1, H2, H3])