import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

from Mfunc import Mfunc
from Hfunc import Hfunc
from AEfunc import AEfunc

# 四連桿長度設定
l1, l2, l3, l4 = 0.2, 0.6, 0.9, 1.0
g = -9.8
Rho1 = 2.7143E3
A_1 = 0.75 * 3 * 10 ** -4

m1 = A_1 * Rho1 * l1
m2 = A_1 * Rho1 * l2
m3 = A_1 * Rho1 * l3

dt = 0.01
T = 12  # 360deg / 30deg/s = 12s
timeSpan = np.arange(0, T + dt, dt)

q1_traj = np.deg2rad(30) * timeSpan
dq1_traj = np.full_like(q1_traj, np.deg2rad(30))
ddq1_traj = np.zeros_like(timeSpan)

def initial_guess(q1):
    return np.deg2rad(70), np.deg2rad(-70)

def fourbar_loop_closure(q1, l1, l2, l3, l4, q2_init, q3_init, tol=1e-12, max_iter=50):
    q2, q3 = q2_init, q3_init
    for _ in range(max_iter):
        F1 = l1 * np.cos(q1) + l2 * np.cos(q2) + l3 * np.cos(q3) - l4
        F2 = l1 * np.sin(q1) + l2 * np.sin(q2) + l3 * np.sin(q3)
        F = np.array([F1, F2])
        J = np.zeros((2,2))
        eps = 1e-8
        for i in range(2):
            dq = np.zeros(2)
            dq[i] = eps
            q2_pert, q3_pert = q2 + dq[0], q3 + dq[1]
            F1p = l1 * np.cos(q1) + l2 * np.cos(q2_pert) + l3 * np.cos(q3_pert) - l4
            F2p = l1 * np.sin(q1) + l2 * np.sin(q2_pert) + l3 * np.sin(q3_pert)
            Fp = np.array([F1p, F2p])
            J[:, i] = (Fp - F) / eps
        dx = np.linalg.solve(J, -F)
        q2 += dx[0]
        q3 += dx[1]
        if np.linalg.norm(dx) < tol:
            break
    return q2, q3

def fourbar_velocity(q1, dq1, q2, q3, l1, l2, l3, l4):
    A = np.array([
        [-l2 * np.sin(q2), -l3 * np.sin(q3)],
        [l2 * np.cos(q2),  l3 * np.cos(q3)]
    ])
    b = np.array([
        l1 * np.sin(q1) * dq1,
        -l1 * np.cos(q1) * dq1
    ])
    dq2_dq3 = np.linalg.solve(A, b)
    dq2, dq3 = dq2_dq3[0], dq2_dq3[1]
    return dq2, dq3

def fourbar_acceleration(q1, dq1, ddq1, q2, dq2, q3, dq3, l1, l2, l3, l4):
    J = np.array([
        [-l2 * np.sin(q2), -l3 * np.sin(q3)],
        [l2 * np.cos(q2),  l3 * np.cos(q3)]
    ])
    b = np.array([
        l1 * np.cos(q1) * dq1**2 + l2 * np.cos(q2) * dq2**2 + l3 * np.cos(q3) * dq3**2,
        l1 * np.sin(q1) * dq1**2 + l2 * np.sin(q2) * dq2**2 + l3 * np.sin(q3) * dq3**2
    ])
    ddq2_ddq3 = np.linalg.solve(J, -b)
    ddq2, ddq3 = ddq2_ddq3[0], ddq2_ddq3[1]
    return ddq2, ddq3

# 運動學分析
q2_traj = np.zeros_like(q1_traj)
q3_traj = np.zeros_like(q1_traj)
dq2_traj = np.zeros_like(q1_traj)
dq3_traj = np.zeros_like(q1_traj)
ddq2_traj = np.zeros_like(q1_traj)
ddq3_traj = np.zeros_like(q1_traj)

q2, q3 = initial_guess(q1_traj[0])
for i, (q1, dq1) in enumerate(zip(q1_traj, dq1_traj)):
    q2, q3 = fourbar_loop_closure(q1, l1, l2, l3, l4, q2, q3)
    dq2, dq3 = fourbar_velocity(q1, dq1, q2, q3, l1, l2, l3, l4)
    ddq2, ddq3 = fourbar_acceleration(q1, dq1, 0, q2, dq2, q3, dq3, l1, l2, l3, l4)
    q2_traj[i] = q2
    q3_traj[i] = q3
    dq2_traj[i] = dq2
    dq3_traj[i] = dq3
    ddq2_traj[i] = ddq2
    ddq3_traj[i] = ddq3

# 計算 torque 歷程（根據你的 Mfunc, Hfunc 定義）
Torque = np.zeros_like(q1_traj)
for i in range(len(timeSpan)):
    q1, q2, q3 = q1_traj[i], q2_traj[i], q3_traj[i]
    dq1, dq2 = dq1_traj[i], dq2_traj[i]
    ddq1, ddq2, ddq3 = ddq1_traj[i], ddq2_traj[i], ddq3_traj[i]
    M = Mfunc(l1, l2, l3, m1, m2, m3, q1, q2)
    H = Hfunc(dq1, dq2, g, l1, l2, l3, m1, m2, m3, q1, q2, q3)
    ddq = np.array([ddq1, ddq2, ddq3])
    Torque[i] = (M[0,:] @ ddq + H[0])

# 分析列印
print("==== 四連桿動力學分析 ====")
print(f"地面桿 l4 = {l4:.3f} m")
print(f"主動短桿 l1 = {l1:.3f} m")
print(f"第二運動桿 l2 = {l2:.3f} m")
print(f"最長運動桿 l3 = {l3:.3f} m")
print(f"各桿質量 m1 = {m1:.3f} kg, m2 = {m2:.3f} kg, m3 = {m3:.3f} kg")
print(f"模擬總時長 T = {T:.2f} s, 時間步長 dt = {dt:.4f} s")
print(f"主動桿角速度 = 30 deg/s, 旋轉 360 deg 一圈")
print(f"主動桿所需最大力矩 = {np.max(np.abs(Torque)):.3f} Nm")
print(f"主動桿力矩平均值 = {np.mean(Torque):.3f} Nm")
print(f"主動桿力矩標準差 = {np.std(Torque):.3f} Nm")
print("主動桿角度範圍: {:.2f} ~ {:.2f} deg".format(np.rad2deg(np.min(q1_traj)), np.rad2deg(np.max(q1_traj))))
x_end = l1 * np.cos(q1_traj) + l2 * np.cos(q2_traj)
y_end = l1 * np.sin(q1_traj) + l2 * np.sin(q2_traj)
print(f"x_end: min={np.min(x_end):.3f} m, max={np.max(x_end):.3f} m")
print(f"y_end: min={np.min(y_end):.3f} m, max={np.max(y_end):.3f} m")

# Constraint error
AE_GM = AEfunc(l1, l2, l3, l4, q1_traj, q2_traj, q3_traj)
print(f"最大 constraint 誤差 = {np.max(np.abs(AE_GM)):.2e}")

# Constraint error 曲線
plt.figure()
plt.plot(timeSpan, AE_GM, color='#77AC30', linewidth=2)
plt.legend(['Constraint Error'])
plt.xlabel('time(s)')
plt.grid(True, which='both')
plt.title('Constraint Error')

# q1, q2, q3 曲線
plt.figure()
plt.plot(timeSpan, np.rad2deg(q1_traj), 'k-', linewidth=1, label='q1')
plt.plot(timeSpan, np.rad2deg(q2_traj), 'b-', linewidth=1, label='q2')
plt.plot(timeSpan, np.rad2deg(q3_traj), 'g-', linewidth=1, label='q3')
plt.legend()
plt.xlabel('time(s)')
plt.ylabel('Angle (deg)')
plt.title('各桿角度')

# 末端點 y 坐標
plt.figure()
plt.plot(timeSpan, y_end, 'k-', linewidth=1.5)
plt.ylabel('y [m]')
plt.xlabel('Time [s]')
plt.title('End-point y')

# 末端點 x 坐標
plt.figure()
plt.plot(timeSpan, x_end, 'b-', linewidth=1.5)
plt.ylabel('X [m]')
plt.xlabel('Time [s]')
plt.title('End-point x')

# Torque 曲線
plt.figure()
plt.plot(timeSpan, Torque, 'r-', linewidth=2)
plt.xlabel('Time [s]')
plt.ylabel('Torque (Nm)')
plt.title('所需主動桿力矩')
plt.grid(True)
plt.show()

# === 動畫模擬 ===
fig, ax = plt.subplots(figsize=(6,6))
ax.set_aspect('equal')
ax.set_xlim(-1.2, 1.2)
ax.set_ylim(-1.2, 1.2)
ax.grid(True)
ground_A = np.array([0, 0])
ground_B = np.array([l4, 0])
line, = ax.plot([], [], 'o-', lw=3, color='tab:blue')
trace, = ax.plot([], [], '-', lw=1, color='tab:red', alpha=0.5)
trace_x, trace_y = [], []

def get_coords(i):
    Ax, Ay = ground_A
    Bx, By = ground_B
    Px = l1 * np.cos(q1_traj[i])
    Py = l1 * np.sin(q1_traj[i])
    Qx = Px + l2 * np.cos(q2_traj[i])
    Qy = Py + l2 * np.sin(q2_traj[i])
    return np.array([
        [Ax, Ay],
        [Px, Py],
        [Qx, Qy],
        [Bx, By]
    ])

def init():
    line.set_data([], [])
    trace.set_data([], [])
    return line, trace

def update(i):
    coords = get_coords(i)
    line.set_data(coords[:,0], coords[:,1])
    trace_x.append(coords[2,0])
    trace_y.append(coords[2,1])
    trace.set_data(trace_x, trace_y)
    return line, trace

ani = FuncAnimation(fig, update, frames=len(timeSpan),
                    init_func=init, blit=True, interval=20, repeat=True)

plt.title('Four-bar Linkage Animation (Dynamics)')
plt.show()