import numpy as np

def GM_dynamics(t, Z, Mfunc, Hfunc, A1func, A1dotfunc):
    """
    投影法 (Generalized Method) 求解四連桿 constrained system dynamics。
    t: 當前時間點
    Z: 狀態向量 [q1, q2, q3, dq1, dq2, dq3]
    Mfunc, Hfunc, A1func, A1dotfunc: 分別為質量矩陣、廣義力、Jacobian 及其導數的函數
    回傳 dZ: 狀態導數 [dq1, dq2, dq3, ddq1, ddq2, ddq3]
    """
    q = Z[:3]     # 廣義座標
    dq = Z[3:6]   # 廣義速度

    q1, q2, q3 = q
    dq1, dq2, dq3 = dq

    # 計算質量矩陣、力、Jacobian 及其導數
    M = Mfunc(l1, l2, l3, m1, m2, m3, q1, q2)
    H = Hfunc(dq1, dq2, g, l1, l2, l3, m1, m2, m3, q1, q2, q3)
    A1 = A1func(l1, l2, l3, q1, q2, q3).T
    A1dot = A1dotfunc(dq1, dq2, dq3, l1, l2, l3, q1, q2, q3).T

    # 設定外力（扭矩）時程
    if t <= 0.7:
        TO = 0.1 * (1 - np.exp(-t / 0.167))   # 前0.7秒較小外力
    else:
        TO = 0

    FTT = np.array([TO, 0, 0])  # 外力只作用於第一座標
    F = FTT - H                 # 扣除廣義力

    # 計算 constraint 投影，消除 constraint 反力對自由度的影響
    A1pinv = np.linalg.pinv(M) @ A1.T
    Lambda = np.linalg.pinv(A1 @ A1pinv)
    # F_G 為扣除 constraint 反力後的廣義力
    F_G = F - A1.T @ (Lambda @ (A1dot @ dq + A1 @ (A1pinv @ F)))

    # 求解加速度
    ddq = np.linalg.pinv(M) @ F_G

    # 合成狀態導數
    dZ = np.concatenate([dq, ddq])
    return dZ