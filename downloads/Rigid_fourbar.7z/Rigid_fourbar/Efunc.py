import numpy as np

def Efunc(dq1, dq2, dq3, g, l1, l2, l3, m1, m2, m3, q1, q2, q3):
    """
    計算系統的總能量（動能＋位能），常用於能量守恆驗證或能量分析。
    dq1, dq2, dq3: 各桿角速度
    g: 重力加速度
    l1, l2, l3: 各桿長
    m1, m2, m3: 各桿質量
    q1, q2, q3: 各桿角度
    返回總能量
    """
    t2 = np.sin(q1)             # q1 的正弦
    t3 = dq1 ** 2               # dq1 平方
    t4 = l1 ** 2                # l1 平方
    # 動能、位能及耦合項的總和
    out1 = (dq2 ** 2 * l2 ** 2 * m2) / 6.0 \
         + (dq3 ** 2 * l3 ** 2 * m3) / 6.0 \
         + (m1 * t3 * t4) / 6.0 \
         + (m2 * t3 * t4) / 2.0 \
         + (g * l1 * m1 * t2) / 2.0 \
         + g * l1 * m2 * t2 \
         + (g * l2 * m2 * np.sin(q2)) / 2.0 \
         + (g * l3 * m3 * np.sin(q3)) / 2.0 \
         + (dq1 * dq2 * l1 * l2 * m2 * np.cos(q1 - q2)) / 2.0
    return out1