import numpy as np

def A1func(l1, l2, l3, q1, q2, q3):
    """
    計算 constraint Jacobian (A1)，用於限制條件的雅可比矩陣。
    l1, l2, l3: 各連桿長度
    q1, q2, q3: 各連桿角度
    返回 shape 為 (3, 2) 的 numpy 陣列
    """
    # 由符號微分展開，對應 constraint 對廣義座標的導數
    arr = [
        -l1 * np.sin(q1),      # 第一行第一列：-l1*sin(q1)
        -l2 * np.sin(q2),      # 第一行第二列：-l2*sin(q2)
        l3 * np.sin(q3),       # 第一行第三列： l3*sin(q3)
        l1 * np.cos(q1),       # 第二行第一列： l1*cos(q1)
        l2 * np.cos(q2),       # 第二行第二列： l2*cos(q2)
        -l3 * np.cos(q3)       # 第二行第三列：-l3*cos(q3)
    ]
    # 將一維陣列 reshape 成 3x2 矩陣
    return np.array(arr).reshape(3, 2)