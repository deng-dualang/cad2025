import os

current_directory = os.getcwd()

print(current_directory)